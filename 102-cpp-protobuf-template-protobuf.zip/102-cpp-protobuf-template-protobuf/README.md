# 102-cpp-protobuf-template

Шаблонный репозиторий задания "Разбор потока length-prefixed Protobuf сообщений на C++" (LEARNING_CENTER-102)